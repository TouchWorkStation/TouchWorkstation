import express from 'express';
import jwt from 'jsonwebtoken';
import os from 'os';
import fs from 'fs';
import path from 'path';
import {execFile, exec, execSync, spawn} from 'child_process';
import {promisify} from 'util';
import crypto from 'crypto';
import http from 'http';
import https from 'https';
import net from 'net';
import {generateRegistrationOptions,verifyRegistrationResponse,generateAuthenticationOptions,verifyAuthenticationResponse} from '@simplewebauthn/server';
import {attachPty} from './pty.js';
import {mountAppRoutes} from './apps-routes.js';
import {mountAgentRoutes} from './agents-routes.js';
import {mountBoardRoutes} from './agent-board-routes.js';
import {mountDockerRoutes} from './docker-routes.js';
import {mountClipboardRoutes} from './clipboard-routes.js';
import {mountNetworkRoutes} from './network-routes.js';

const sh=promisify(exec);
const app=express();
app.set('trust proxy','loopback');
// 12mb to fit a base64-encoded wallpaper upload (see /api/wallpaper) — a
// route-specific limit would be pointless here, since this global parser
// runs first on every request and a stricter one downstream never gets the
// chance to override an already-rejected oversized body.
app.use(express.json({limit:'12mb'}));
const PORT=Number(process.env.PORT||8787);
const HOME=process.env.TW_HOME||os.homedir();

// The commit this server was built from, so the UI can show what's actually
// running and warn if the frontend bundle it loaded doesn't match. Same
// three-source resolution as the vite config uses: prefer build-info.json
// (written by the packaging step), fall back to `git rev-parse` (dev),
// fall back to 'unknown' (never fail startup over this).
function resolveBuildSha(){
  try{
    const p=path.resolve(process.cwd(),'build-info.json');
    const info=JSON.parse(fs.readFileSync(p,'utf8'));
    if(info?.sha)return String(info.sha).slice(0,12);
  }catch{}
  try{
    return execSync('git rev-parse --short=12 HEAD',{cwd:process.cwd()}).toString().trim();
  }catch{}
  return 'unknown';
}
const BUILD_SHA=resolveBuildSha();
const PROCESS_STARTED_AT=new Date().toISOString();

const CRASH_LOG_FILE=path.join(HOME,'.touchworkstation','crash-log.json');
function recordCrash(kind,err){
  try{
    fs.mkdirSync(path.dirname(CRASH_LOG_FILE),{recursive:true});
    let log=[];
    try{log=JSON.parse(fs.readFileSync(CRASH_LOG_FILE,'utf8'))}catch{}
    log.push({
      at:new Date().toISOString(),
      kind, // 'uncaughtException' | 'unhandledRejection'
      message:String(err?.message||err),
      stack:String(err?.stack||''),
    });
    // Keep this bounded — a crash loop shouldn't grow this file forever.
    if(log.length>20)log=log.slice(-20);
    fs.writeFileSync(CRASH_LOG_FILE,JSON.stringify(log,null,2));
  }catch{ /* if we can't even write the crash log, there's nothing more to do here */ }
}
process.on('uncaughtException',(err)=>{
  recordCrash('uncaughtException',err);
  console.error('Uncaught exception — exiting for a clean restart:',err);
  process.exit(1);
});
process.on('unhandledRejection',(reason)=>{
  recordCrash('unhandledRejection',reason);
  console.error('Unhandled rejection — exiting for a clean restart:',reason);
  process.exit(1);
});
// Build a PATH that includes the user's own install dirs so npm/node/vite and
// user-installed CLIs run under the minimal systemd service PATH. This is the
// same fix applied to detection and the terminal — without it, a freshly
// cloned repo's dev server can't find its tools and dies, so the preview
// never comes up.
function twPath(){
  const extra=[`${HOME}/.local/bin`,`${HOME}/.npm-global/bin`,`${HOME}/bin`,`${HOME}/.cargo/bin`,`${HOME}/.deno/bin`,`${HOME}/.bun/bin`,'/usr/local/bin','/usr/bin','/bin','/snap/bin'];
  try{const nvm=`${HOME}/.nvm/versions/node`;if(fs.existsSync(nvm))for(const v of fs.readdirSync(nvm))extra.push(`${nvm}/${v}/bin`)}catch{}
  return [...new Set([...(process.env.PATH||'').split(':'),...extra])].filter(Boolean).join(':');
}
const {
  NODE_ENV:_ignoredNodeEnv,
  // Whatever process happens to be running this server (a systemd unit gets
  // a clean, explicitly-declared environment and would never have these —
  // but `node server/index.js` run by hand in a terminal that's also been
  // used for other git work inherits its exact ambient state) must never
  // leak git's own plumbing vars into a spawned child. GIT_DIR set without a
  // matching GIT_WORK_TREE makes git treat every command as operating on a
  // bare repo — "fatal: this operation must be run in a work tree" on
  // something like `git reset --hard`, no matter what directory the script
  // itself `cd`s into first. Hit this for real: the update-build spawn
  // (`/api/update/apply` below) failed exactly this way.
  GIT_DIR:_ignoredGitDir,GIT_WORK_TREE:_ignoredGitWorkTree,
  GIT_INDEX_FILE:_ignoredGitIndexFile,GIT_OBJECT_DIRECTORY:_ignoredGitObjectDir,
  ...ENV_NO_NODE_ENV
}=process.env;
// Never let NODE_ENV=production leak into project installs/dev servers.
// With it set, `npm install` silently skips ALL devDependencies (exit 0, no
// error) — and vite/next/etc. live there, so the dev server binary never
// gets installed even though the install step reports success. This was the
// actual root cause of "vite: not found" after an install that looked fine.
const SPAWN_ENV={...ENV_NO_NODE_ENV,PATH:twPath()};

// Hermes ships a local web gateway. This endpoint finds the running gateway
// (or starts it) and returns a same-origin proxied URL so the UI opens in a
// webview instead of a terminal. We probe the ports Hermes commonly uses.
const HERMES_PORTS=[8787+1,8080,3000,7860,8000,5000,8788];
async function probePort(p){return new Promise(r=>{const s=net.createConnection({host:'127.0.0.1',port:p,timeout:600});s.once('connect',()=>{s.destroy();r(true)});s.once('error',()=>{s.destroy();r(false)});s.once('timeout',()=>{s.destroy();r(false)})})}
// APP_PASSWORD is mutable at runtime: a fresh install ships a random
// generated password and PW_MUST_CHANGE=1, and the user is required to set
// their own before using the app. Changing it rewrites the env file on disk
// (the source of truth postinst/systemd read) and updates this process's
// in-memory copy, so no restart is needed.
let APP_PASSWORD=process.env.APP_PASSWORD||'changeme';
let PW_MUST_CHANGE=process.env.PW_MUST_CHANGE==='1';
const ENV_FILE=process.env.TW_ENV_FILE||'/etc/touchworkstation/touchworkstation.env';
const JWT_SECRET=process.env.JWT_SECRET||'dev-only-change-me';
const STATE_DIR=process.env.TW_STATE_DIR||path.join(HOME,'.local/share/touchworkstation');
const RUN_DIR=path.join(STATE_DIR,'run');
const CONFIG_FILE=path.join(STATE_DIR,'config.json');
const PROJECTS_DEFAULT=path.join(HOME,'TouchWorkstation','Projects');
fs.mkdirSync(RUN_DIR,{recursive:true});
fs.mkdirSync(PROJECTS_DEFAULT,{recursive:true});
let runners=new Map();

function parseCookies(req){return Object.fromEntries((req.headers.cookie||'').split(';').map(x=>x.trim()).filter(Boolean).map(x=>{const i=x.indexOf('=');return [x.slice(0,i),decodeURIComponent(x.slice(i+1))]}));}
function auth(req,res,next){try{const t=parseCookies(req).tw_session||req.headers.authorization?.replace('Bearer ','');if(!t)throw 0;req.user=jwt.verify(t,JWT_SECRET);next()}catch{res.status(401).json({error:'Not authenticated'})}}
// Constant-time password comparison — avoids leaking the password length/prefix
// through response timing. Hash both sides to a fixed length first so
// timingSafeEqual never throws on a length mismatch (which would itself leak).
function pwEqual(a,b){
  const ha=crypto.createHash('sha256').update(String(a)).digest();
  const hb=crypto.createHash('sha256').update(String(b)).digest();
  return crypto.timingSafeEqual(ha,hb);
}
// Mark the session cookie Secure only when the request actually arrived over
// TLS (the optional 8443 listener) — plain-HTTP LAN use must keep working, and
// a Secure cookie would simply be dropped there.
function sessionCookie(token,req){
  return `tw_session=${encodeURIComponent(token)}; HttpOnly; SameSite=Lax; Path=/; Max-Age=2592000`+(req.secure?'; Secure':'');
}
// Brute-force protection for the one unauthenticated endpoint: after a few bad
// attempts from an IP, lock it out with exponential backoff (30s → capped at
// 15min). In-memory only — a restart clears it, which is fine for a personal
// tool. Keyed by req.ip (trust proxy is 'loopback', so the nginx-forwarded IP
// is used when present).
const loginFails=new Map(); // ip -> {fails, until}
function loginLocked(ip){const e=loginFails.get(ip);return e&&e.until>Date.now()?Math.ceil((e.until-Date.now())/1000):0}
function noteLoginResult(ip,ok){
  if(ok){loginFails.delete(ip);return}
  const e=loginFails.get(ip)||{fails:0,until:0};
  e.fails++;
  if(e.fails>=5){const backoff=Math.min(15*60*1000,30000*2**(e.fails-5));e.until=Date.now()+backoff}
  loginFails.set(ip,e);
}
app.post('/api/login',(req,res)=>{
  const wait=loginLocked(req.ip);
  if(wait)return res.status(429).json({error:`Too many attempts. Try again in ${wait>60?Math.ceil(wait/60)+' min':wait+'s'}.`});
  if(!pwEqual(req.body.password,APP_PASSWORD)){noteLoginResult(req.ip,false);return res.status(401).json({error:'Invalid password'})}
  noteLoginResult(req.ip,true);
  const token=jwt.sign({sub:os.userInfo().username},JWT_SECRET,{expiresIn:'30d'});
  res.setHeader('Set-Cookie',sessionCookie(token,req));
  res.json({ok:true,mustChangePassword:PW_MUST_CHANGE});
});
app.get('/api/me',auth,(req,res)=>res.json({hostname:os.hostname(),user:os.userInfo().username,version:'1.0.0-beta.57',build:BUILD_SHA,startedAt:PROCESS_STARTED_AT,mustChangePassword:PW_MUST_CHANGE}));

// Rewrite APP_PASSWORD= (and clear PW_MUST_CHANGE) in the env file in place,
// preserving every other line, so systemd/postinst keep reading the same
// source of truth on the next boot or upgrade.
function persistPassword(newPassword){
  let lines=[];
  try{lines=fs.readFileSync(ENV_FILE,'utf8').split('\n')}catch{ /* fresh/dev env, nothing to preserve */ }
  let sawPw=false,sawFlag=false;
  lines=lines.map(l=>{
    if(l.startsWith('APP_PASSWORD=')){sawPw=true;return `APP_PASSWORD=${newPassword}`}
    if(l.startsWith('PW_MUST_CHANGE=')){sawFlag=true;return 'PW_MUST_CHANGE=0'}
    return l;
  });
  if(!sawPw)lines.push(`APP_PASSWORD=${newPassword}`);
  if(!sawFlag)lines.push('PW_MUST_CHANGE=0');
  const out=lines.filter((l,i)=>l!==''||i<lines.length-1).join('\n');
  try{fs.writeFileSync(ENV_FILE,out.endsWith('\n')?out:out+'\n',{mode:0o640})}
  catch(e){throw new Error('Could not save the new password to '+ENV_FILE+': '+e.message)}
}

app.post('/api/change-password',auth,(req,res)=>{
  const {currentPassword,newPassword}=req.body||{};
  if(!pwEqual(currentPassword,APP_PASSWORD))return res.status(401).json({error:'Current password is incorrect'});
  const np=String(newPassword||'');
  if(np.length<8)return res.status(400).json({error:'New password must be at least 8 characters'});
  if(pwEqual(np,APP_PASSWORD))return res.status(400).json({error:'Choose a password different from the current one'});
  try{persistPassword(np)}catch(e){return res.status(500).json({error:e.message})}
  APP_PASSWORD=np;PW_MUST_CHANGE=false;
  res.json({ok:true});
});

// ---- Biometric unlock (WebAuthn passkeys) ----------------------------------
// Lets the phone's Face ID / fingerprint unlock the app instead of typing the
// password. Requires a secure context (the browser enforces this), so it only
// works over HTTPS (the built-in 8443 listener via a Tailscale cert, or an
// HTTPS reverse proxy). The UI hides it otherwise and falls back to password.
const PASSKEYS_FILE=path.join(STATE_DIR,'passkeys.json');
function loadPasskeys(){try{return JSON.parse(fs.readFileSync(PASSKEYS_FILE,'utf8'))}catch{return[]}}
function savePasskeys(list){fs.mkdirSync(path.dirname(PASSKEYS_FILE),{recursive:true});fs.writeFileSync(PASSKEYS_FILE,JSON.stringify(list,null,2),{mode:0o600});try{fs.chmodSync(PASSKEYS_FILE,0o600)}catch{}}
const b64uToBuf=s=>Buffer.from(String(s),'base64url');
const bufToB64u=b=>Buffer.from(b).toString('base64url');
// Origin/RP id come from the browser's own Origin header so verification matches
// whatever hostname the user actually reached the app on (ts.net, .local, etc).
function rpInfo(req){
  let origin=req.headers.origin;
  if(!origin){const proto=req.secure?'https':'http';origin=`${proto}://${req.headers.host}`}
  let rpID;try{rpID=new URL(origin).hostname}catch{rpID=os.hostname()}
  return {origin,rpID};
}
// Short-lived challenge store, keyed by a cookie so the register/authenticate
// two-step survives across the two requests without a logged-in session.
const waChallenges=new Map(); // id -> {challenge, exp}
function setChallenge(res,req,challenge){
  const id=crypto.randomBytes(18).toString('base64url');
  waChallenges.set(id,{challenge,exp:Date.now()+300000});
  res.setHeader('Set-Cookie',`tw_wa=${id}; HttpOnly; SameSite=Lax; Path=/; Max-Age=300`+(req.secure?'; Secure':''));
}
function takeChallenge(req){
  const id=parseCookies(req).tw_wa;const e=id&&waChallenges.get(id);
  if(!e||e.exp<Date.now())return null;
  waChallenges.delete(id);return e.challenge;
}
app.get('/api/webauthn/available',(req,res)=>res.json({hasPasskey:loadPasskeys().length>0}));
app.post('/api/webauthn/register/options',auth,async(req,res)=>{
  try{
    const {rpID}=rpInfo(req);
    const existing=loadPasskeys();
    const opts=await generateRegistrationOptions({
      rpName:'TouchWorkstation',rpID,
      userName:os.userInfo().username||'user',
      userID:new Uint8Array(crypto.createHash('sha256').update(os.userInfo().username||'user').digest()),
      attestationType:'none',
      excludeCredentials:existing.map(c=>({id:c.id,transports:c.transports})),
      authenticatorSelection:{residentKey:'preferred',userVerification:'preferred'},
    });
    setChallenge(res,req,opts.challenge);
    res.json(opts);
  }catch(e){res.status(500).json({error:e.message})}
});
app.post('/api/webauthn/register/verify',auth,async(req,res)=>{
  try{
    const expectedChallenge=takeChallenge(req);
    if(!expectedChallenge)throw new Error('Registration expired — try again');
    const {origin,rpID}=rpInfo(req);
    const v=await verifyRegistrationResponse({response:req.body?.credential||req.body,expectedChallenge,expectedOrigin:origin,expectedRPID:rpID,requireUserVerification:false});
    if(!v.verified||!v.registrationInfo)throw new Error('Could not verify this device');
    const c=v.registrationInfo.credential;
    const list=loadPasskeys();
    list.push({id:c.id,publicKey:bufToB64u(c.publicKey),counter:c.counter||0,transports:c.transports||[],label:String(req.body?.label||'').slice(0,60)||'This device',createdAt:new Date().toISOString()});
    savePasskeys(list);
    res.json({ok:true});
  }catch(e){res.status(400).json({error:e.message})}
});
app.get('/api/webauthn/credentials',auth,(req,res)=>res.json({credentials:loadPasskeys().map(c=>({id:c.id,label:c.label,createdAt:c.createdAt}))}));
app.delete('/api/webauthn/credentials/:id',auth,(req,res)=>{
  const list=loadPasskeys();const next=list.filter(c=>c.id!==req.params.id);
  if(next.length===list.length)return res.status(404).json({error:'Not found'});
  savePasskeys(next);res.json({ok:true});
});
app.post('/api/webauthn/auth/options',(req,res)=>{
  try{
    const list=loadPasskeys();
    if(!list.length)return res.status(400).json({error:'No passkeys registered'});
    const {rpID}=rpInfo(req);
    // generateAuthenticationOptions is sync-return-Promise in v13; await it.
    generateAuthenticationOptions({rpID,userVerification:'preferred',allowCredentials:list.map(c=>({id:c.id,transports:c.transports}))})
      .then(opts=>{setChallenge(res,req,opts.challenge);res.json(opts)})
      .catch(e=>res.status(500).json({error:e.message}));
  }catch(e){res.status(500).json({error:e.message})}
});
app.post('/api/webauthn/auth/verify',async(req,res)=>{
  try{
    const wait=loginLocked(req.ip);
    if(wait)return res.status(429).json({error:`Too many attempts. Try again in ${wait>60?Math.ceil(wait/60)+' min':wait+'s'}.`});
    const expectedChallenge=takeChallenge(req);
    if(!expectedChallenge)throw new Error('Sign-in expired — try again');
    const {origin,rpID}=rpInfo(req);
    const resp=req.body?.credential||req.body;
    const list=loadPasskeys();
    const cred=list.find(c=>c.id===resp.id);
    if(!cred){noteLoginResult(req.ip,false);throw new Error('Unknown passkey')}
    const v=await verifyAuthenticationResponse({response:resp,expectedChallenge,expectedOrigin:origin,expectedRPID:rpID,requireUserVerification:false,
      credential:{id:cred.id,publicKey:new Uint8Array(b64uToBuf(cred.publicKey)),counter:cred.counter,transports:cred.transports}});
    if(!v.verified){noteLoginResult(req.ip,false);throw new Error('Verification failed')}
    cred.counter=v.authenticationInfo.newCounter;savePasskeys(list);
    noteLoginResult(req.ip,true);
    const token=jwt.sign({sub:os.userInfo().username},JWT_SECRET,{expiresIn:'30d'});
    res.setHeader('Set-Cookie',sessionCookie(token,req));
    res.json({ok:true});
  }catch(e){res.status(400).json({error:e.message})}
});
let lastCpuSample=null;
function cpuSnapshot(){const cpus=os.cpus();let idle=0,total=0;for(const c of cpus){idle+=c.times.idle;for(const t of Object.values(c.times))total+=t}return{idle,total}}
function liveCpu(){const cur=cpuSnapshot();if(!lastCpuSample){lastCpuSample=cur;return Math.max(0,Math.min(100,Math.round((1-cur.idle/cur.total)*100)))}const di=cur.idle-lastCpuSample.idle,dt=cur.total-lastCpuSample.total;lastCpuSample=cur;if(dt<=0)return 0;return Math.max(0,Math.min(100,Math.round((1-di/dt)*100)))}
// List active tmux sessions TouchWorkstation created (prefixed tw-), so the
// terminal switcher can show what's really running instead of guessing.
// Sessions persist across app closes/reconnects by design (tmux -A
// reattaches), so this is the only reliable source of truth for "what
// terminals do I actually have open right now".
// Whether the shared 'main' terminal session is free to reuse right now.
// "Free" means its foreground process is a plain shell (bash/sh/zsh) —
// anything else (an agent CLI mid-conversation, a long-running command)
// means typing another command into it would go to the wrong program, so
// the caller should open a fresh session instead. This is what lets
// "one terminal by default" behave safely: reuse main when it's idle,
// don't silently interrupt something that's actively running.
const SHELL_NAMES=new Set(['bash','sh','zsh','fish','dash']);
app.get('/api/terminal/main-busy',auth,async(req,res)=>{
  try{
    const {stdout}=await sh("tmux list-panes -t tw-main -F '#{pane_current_command}' 2>/dev/null || true",{env:SPAWN_ENV});
    const cmd=stdout.trim().split('\n')[0]||'';
    if(!cmd)return res.json({exists:false,busy:false}); // session doesn't exist yet -> definitely free
    res.json({exists:true,busy:!SHELL_NAMES.has(cmd),runningCommand:cmd});
  }catch{
    res.json({exists:false,busy:false});
  }
});
app.get('/api/terminal/sessions',auth,async(req,res)=>{
  try{
    // Use an explicit delimiter unlikely to appear in a session name, rather
    // than a literal tab — a tab character passed through exec's shell
    // quoting was getting silently mangled, corrupting the parsed fields.
    const {stdout}=await sh("tmux list-sessions -F '#{session_name}::TWSEP::#{session_created}::TWSEP::#{session_attached}' 2>/dev/null || true",{env:SPAWN_ENV});
    const sessions=stdout.trim().split('\n').filter(Boolean).map(line=>{
      const [name,created,attached]=line.split('::TWSEP::');
      if(!name||!name.startsWith('tw-'))return null;
      return {id:name.slice(3),createdAt:Number(created)*1000,attached:attached==='1'};
    }).filter(Boolean);
    res.json({sessions,tmux:true});
  }catch{
    res.json({sessions:[],tmux:false});
  }
});
// Close (kill) a specific terminal session entirely, rather than just
// detaching from it. Used by the switcher's "close" action.
app.post('/api/terminal/sessions/:id/close',auth,async(req,res)=>{
  const id=String(req.params.id||'').replace(/[^a-zA-Z0-9_-]/g,'').slice(0,64);
  if(!id)return res.status(400).json({error:'Invalid session id'});
  try{await sh(`tmux kill-session -t ${JSON.stringify('tw-'+id)}`,{env:SPAWN_ENV});res.json({ok:true})}
  catch(e){res.status(400).json({error:String(e.stderr||e.message)})}
});
app.get('/api/terminal/sessions/:id/history',auth,async(req,res)=>{
  const id=String(req.params.id||'').replace(/[^a-zA-Z0-9_-]/g,'').slice(0,64);
  if(!id)return res.status(400).json({error:'Invalid session id'});
  try{
    const {stdout}=await sh(`tmux capture-pane -t ${JSON.stringify('tw-'+id)} -p -e -S -3000`,{env:SPAWN_ENV});
    res.json({text:stdout});
  }catch(e){res.status(400).json({error:String(e.stderr||e.message)})}
});
app.get('/api/crash-log',auth,(req,res)=>{
  // Only crashes from BEFORE this process started are noise now — the crash
  // that caused the restart is captured to disk, then the fresh process
  // reads its own start time and treats anything older as history. A
  // crash-loop from a previous session (e.g. 48 EADDRINUSE entries from a
  // stuck port) doesn't show as "8 restarts happened while you were away"
  // to a user who just successfully restarted the service.
  try{
    const log=JSON.parse(fs.readFileSync(CRASH_LOG_FILE,'utf8'));
    const arr=Array.isArray(log)?log:[];
    const sinceCurrent=arr.filter(c=>c?.at&&c.at>=PROCESS_STARTED_AT);
    res.json({crashes:sinceCurrent,startedAt:PROCESS_STARTED_AT});
  }catch{res.json({crashes:[],startedAt:PROCESS_STARTED_AT})}
});
app.post('/api/crash-log/ack',auth,(req,res)=>{
  try{fs.writeFileSync(CRASH_LOG_FILE,'[]')}catch{}
  res.json({ok:true});
});
let lastNet=null; // {rx,tx,at} — previous /proc/net/dev sample, for rate calculation
function netRates(){
  try{
    const lines=fs.readFileSync('/proc/net/dev','utf8').split('\n').slice(2);
    let rx=0,tx=0;
    for(const line of lines){
      const m=line.trim().match(/^([^:]+):\s*(.+)$/);
      if(!m||m[1]==='lo')continue;
      const cols=m[2].trim().split(/\s+/).map(Number);
      rx+=cols[0]||0; tx+=cols[8]||0;
    }
    const now=Date.now();
    let rxRate=0,txRate=0;
    if(lastNet){
      const dt=(now-lastNet.at)/1000;
      if(dt>0){rxRate=Math.max(0,(rx-lastNet.rx)/dt);txRate=Math.max(0,(tx-lastNet.tx)/dt)}
    }
    lastNet={rx,tx,at:now};
    return {rxBps:rxRate,txBps:txRate};
  }catch{return {rxBps:0,txBps:0}}
}
// GPU/VRAM detection for the cluster view. Try nvidia-smi first, then AMD's
// rocm-smi; return [] when neither is present (integrated/headless boxes) so
// the dashboard just shows "no GPU" rather than erroring. Memory is reported
// in MB by both tools; we keep MB and let the UI format.
function detectGpus(){
  // nvidia-smi: one CSV row per GPU — name, total MB, used MB, util %.
  try{
    const out=sync('nvidia-smi --query-gpu=name,memory.total,memory.used,utilization.gpu --format=csv,noheader,nounits 2>/dev/null',SPAWN_ENV);
    if(out){
      const gpus=out.split('\n').map(l=>l.trim()).filter(Boolean).map(l=>{
        const [name,total,used,util]=l.split(',').map(x=>(x||'').trim());
        return {name:name||'GPU',vramTotalMB:Number(total)||0,vramUsedMB:Number(used)||0,util:Number(util)||0,vendor:'nvidia'};
      });
      if(gpus.length)return gpus;
    }
  }catch{}
  // rocm-smi (AMD): parse the JSON form for VRAM total/used and GPU use %.
  try{
    const raw=sync('rocm-smi --showproductname --showmeminfo vram --showuse --json 2>/dev/null',SPAWN_ENV);
    if(raw){
      const j=JSON.parse(raw);
      const gpus=[];
      for(const [k,v] of Object.entries(j)){
        if(!/^card\d+$/i.test(k))continue;
        const totalB=Number(v['VRAM Total Memory (B)']||v['vram total memory (b)']||0);
        const usedB=Number(v['VRAM Total Used Memory (B)']||v['vram total used memory (b)']||0);
        const util=Number((v['GPU use (%)']||v['gpu use (%)']||'0').toString().replace(/[^\d.]/g,''))||0;
        const name=(v['Card series']||v['Card model']||v['Card SKU']||'AMD GPU').toString();
        gpus.push({name,vramTotalMB:Math.round(totalB/1048576),vramUsedMB:Math.round(usedB/1048576),util,vendor:'amd'});
      }
      if(gpus.length)return gpus;
    }
  }catch{}
  return [];
}
// Shared by /api/status and the cluster aggregator so both report the exact
// same per-machine spec shape.
async function computeStatus(){
  let disk=0,diskUsedGB=0,diskTotalGB=0;
  try{
    // df -P gives POSIX-stable column order: size, used, avail, %used, mount.
    // Values come back in 1K blocks; convert to GB for a human-readable spec.
    const {stdout}=await sh("df -P / | tail -1 | awk '{print $2, $3, $5}'");
    const [totalKB,usedKB,pct]=stdout.trim().split(/\s+/);
    disk=parseInt(pct)||0;
    diskTotalGB=Math.round((Number(totalKB)||0)/1024/1024*10)/10;
    diskUsedGB=Math.round((Number(usedKB)||0)/1024/1024*10)/10;
  }catch{}
  const cpu=liveCpu();
  const memTotalBytes=os.totalmem(),memFreeBytes=os.freemem();
  const memory=Math.round((1-memFreeBytes/memTotalBytes)*100);
  const memTotalGB=Math.round(memTotalBytes/1073741824*10)/10;
  const memUsedGB=Math.round((memTotalBytes-memFreeBytes)/1073741824*10)/10;
  const cpus=os.cpus();
  const ip=Object.values(os.networkInterfaces()).flat().find(x=>x&&x.family==='IPv4'&&!x.internal)?.address;
  const net=netRates();
  const gpus=detectGpus();
  return {
    cpu,memory,disk,ip,uptime:os.uptime(),net,
    specs:{
      cpuCores:cpus.length,
      cpuModel:(cpus[0]?.model||'').replace(/\s+/g,' ').trim(),
      memUsedGB,memTotalGB,
      diskUsedGB,diskTotalGB,
      gpus,
    },
  };
}
app.get('/api/status',auth,async(req,res)=>{res.json(await computeStatus())});

// Resolve a path and guarantee it stays inside HOME. The equality check plus
// the trailing-separator prefix is deliberate: a bare startsWith(HOME) would
// also accept a sibling like /home/chris-evil for HOME=/home/chris. This guard
// now protects write/delete endpoints too, so that edge matters.
function safeHome(p=''){const H=path.resolve(HOME);const resolved=path.resolve(H,p||H);if(resolved!==H&&!resolved.startsWith(H+path.sep))throw new Error('Path outside home directory is blocked');return resolved}
// Classify a file by extension so the client knows what it can preview inline.
function fileKind(name){
  const e=(name.split('.').pop()||'').toLowerCase();
  if(['png','jpg','jpeg','gif','webp','bmp','svg','avif','ico'].includes(e))return'image';
  if(e==='pdf')return'pdf';
  if(['mp4','webm','mov','mkv','m4v'].includes(e))return'video';
  if(['mp3','wav','ogg','flac','m4a','aac','opus'].includes(e))return'audio';
  if(['txt','md','markdown','json','js','jsx','ts','tsx','css','scss','html','xml','yml','yaml','toml','ini','conf','sh','bash','py','rs','go','c','h','cpp','java','rb','php','sql','log','env','gitignore','csv'].includes(e))return'text';
  return'other';
}
// A single path segment safe to write to disk: no separators, no traversal.
function safeName(name){const n=String(name||'').replace(/[/\\]/g,'').replace(/^\.+/,'').trim();if(!n||n==='.'||n==='..')throw new Error('Invalid name');return n.slice(0,255)}
app.get('/api/files',auth,(req,res)=>{try{
  const p=safeHome(req.query.path||HOME);
  const all=req.query.all==='1';
  const entries=fs.readdirSync(p,{withFileTypes:true})
    .filter(x=>all||!x.name.startsWith('.'))
    .map(x=>{
      const full=path.join(p,x.name);
      const dir=x.isDirectory();
      let size=0,mtimeMs=0;
      try{const st=fs.statSync(full);size=st.size;mtimeMs=st.mtimeMs}catch{}
      return {name:x.name,directory:dir,path:full,size,mtimeMs,kind:dir?'folder':fileKind(x.name)};
    })
    .sort((a,b)=>Number(b.directory)-Number(a.directory)||a.name.localeCompare(b.name));
  const parent=p===path.resolve(HOME)?null:path.dirname(p);
  res.json({path:p,parent,home:path.resolve(HOME),entries});
}catch(e){res.status(400).json({error:e.message})}});

// Read/write a single file's raw contents — the Tiled Omarchy layout's
// config-editor pane. Deliberately separate from /api/files (which only
// ever lists directories) rather than overloading it, and reuses the same
// safeHome() guard so this can't read/write outside the home directory any
// more than the file browser itself already can.
app.get('/api/file-content',auth,(req,res)=>{
  try{
    if(!req.query.path)throw new Error('path is required');
    const p=safeHome(req.query.path);
    const stat=fs.statSync(p);
    if(stat.isDirectory())throw new Error('That path is a directory, not a file');
    if(stat.size>2_000_000)throw new Error('File is too large to edit here (max 2MB)');
    res.json({path:p,content:fs.readFileSync(p,'utf8')});
  }catch(e){res.status(400).json({error:e.message})}
});
app.post('/api/file-content',auth,(req,res)=>{
  try{
    if(!req.body?.path)throw new Error('path is required');
    const p=safeHome(req.body.path);
    fs.writeFileSync(p,String(req.body.content??''));
    res.json({ok:true});
  }catch(e){res.status(400).json({error:e.message})}
});

// ---- File manager: serve, download, upload, and organize files -------------
// All guarded by safeHome() so nothing escapes the home directory, the same
// boundary the browser/editor already enforce.
const RAW_TYPES={png:'image/png',jpg:'image/jpeg',jpeg:'image/jpeg',gif:'image/gif',webp:'image/webp',bmp:'image/bmp',svg:'image/svg+xml',avif:'image/avif',ico:'image/x-icon',pdf:'application/pdf',mp4:'video/mp4',webm:'video/webm',mov:'video/quicktime',mkv:'video/x-matroska',m4v:'video/mp4',mp3:'audio/mpeg',wav:'audio/wav',ogg:'audio/ogg',flac:'audio/flac',m4a:'audio/mp4',aac:'audio/aac',opus:'audio/opus'};
// Inline serve for previews (image/PDF/video/audio). sendFile handles Range
// requests on its own, so video/audio seek correctly.
app.get('/api/files/raw',auth,(req,res)=>{
  try{
    const p=safeHome(req.query.path);
    const st=fs.statSync(p);
    if(st.isDirectory())throw new Error('That path is a directory');
    const ext=(p.split('.').pop()||'').toLowerCase();
    if(RAW_TYPES[ext])res.type(RAW_TYPES[ext]);
    res.sendFile(p,{dotfiles:'allow',headers:{'Cache-Control':'no-store'}});
  }catch(e){res.status(400).json({error:e.message})}
});
// Attachment download (save to the phone).
app.get('/api/files/download',auth,(req,res)=>{
  try{
    const p=safeHome(req.query.path);
    if(fs.statSync(p).isDirectory())throw new Error('Cannot download a folder');
    res.download(p,path.basename(p),{dotfiles:'allow'});
  }catch(e){res.status(400).json({error:e.message})}
});
// Upload: the raw request body is the file bytes (application/octet-stream), so
// express.json never touches it and there's no multipart dependency — the same
// dependency-free philosophy as the wallpaper upload, but streamed so large
// files don't buffer in memory.
app.post('/api/files/upload',auth,(req,res)=>{
  try{
    const dir=safeHome(req.query.path||HOME);
    if(!fs.statSync(dir).isDirectory())throw new Error('Upload target is not a folder');
    const name=safeName(req.query.name);
    const dest=path.join(dir,name);
    if(dest!==safeHome(dest))throw new Error('Invalid destination');
    if(fs.existsSync(dest)&&req.query.overwrite!=='1')return res.status(409).json({error:'A file with that name already exists'});
    const out=fs.createWriteStream(dest);
    req.pipe(out);
    out.on('finish',()=>res.json({ok:true,path:dest}));
    out.on('error',e=>{try{fs.unlinkSync(dest)}catch{};res.status(500).json({error:e.message})});
    req.on('error',()=>{try{out.destroy();fs.unlinkSync(dest)}catch{}});
  }catch(e){res.status(400).json({error:e.message})}
});
app.post('/api/files/mkdir',auth,(req,res)=>{
  try{
    const dir=safeHome(req.body?.path||HOME);
    const dest=path.join(dir,safeName(req.body?.name));
    if(dest!==safeHome(dest))throw new Error('Invalid destination');
    if(fs.existsSync(dest))throw new Error('That folder already exists');
    fs.mkdirSync(dest);
    res.json({ok:true,path:dest});
  }catch(e){res.status(400).json({error:e.message})}
});
app.post('/api/files/rename',auth,(req,res)=>{
  try{
    const p=safeHome(req.body?.path);
    const dest=path.join(path.dirname(p),safeName(req.body?.newName));
    if(dest!==safeHome(dest))throw new Error('Invalid name');
    if(fs.existsSync(dest))throw new Error('A file with that name already exists');
    fs.renameSync(p,dest);
    res.json({ok:true,path:dest});
  }catch(e){res.status(400).json({error:e.message})}
});
app.post('/api/files/move',auth,(req,res)=>{
  try{
    const p=safeHome(req.body?.path);
    const destDir=safeHome(req.body?.dest);
    if(!fs.statSync(destDir).isDirectory())throw new Error('Destination is not a folder');
    const dest=path.join(destDir,path.basename(p));
    if(dest!==safeHome(dest))throw new Error('Invalid destination');
    if(fs.existsSync(dest))throw new Error('A file with that name already exists there');
    fs.renameSync(p,dest);
    res.json({ok:true,path:dest});
  }catch(e){res.status(400).json({error:e.message})}
});
app.post('/api/files/delete',auth,(req,res)=>{
  try{
    const p=safeHome(req.body?.path);
    if(p===path.resolve(HOME))throw new Error('Refusing to delete the home directory');
    fs.rmSync(p,{recursive:true,force:true});
    res.json({ok:true});
  }catch(e){res.status(400).json({error:e.message})}
});

// Compact process list for the Tiled Omarchy layout's process-list pane —
// same shape as `top`/`btop`'s summary columns, sorted by CPU like those
// tools default to, capped at 20 rows since this is a glanceable tile, not
// a full process manager.
app.get('/api/processes',auth,async(req,res)=>{
  try{
    const {stdout}=await sh("ps -eo pid,user:20,pcpu,pmem,comm --no-headers --sort=-pcpu | head -20",{env:SPAWN_ENV});
    const processes=stdout.trim().split('\n').filter(Boolean).map((line)=>{
      const [pid,user,cpu,mem,...rest]=line.trim().split(/\s+/);
      return {pid:Number(pid),user,cpu:Number(cpu),mem:Number(mem),command:rest.join(' ')};
    });
    res.json({processes});
  }catch(e){res.status(400).json({error:e.message})}
});

app.post('/api/terminal/exec',auth,async(req,res)=>{const command=String(req.body.command||'').trim();if(!command)return res.json({output:''});try{const {stdout,stderr}=await sh(command,{cwd:HOME,timeout:30000,maxBuffer:2_000_000,shell:'/bin/bash'});res.json({output:(stdout||'')+(stderr||'')})}catch(e){res.status(400).json({error:(e.stdout||'')+(e.stderr||e.message)})}});

// All block devices (physical disks + partitions), with per-mount usage — for
// the Disks screen on a workstation with several drives. lsblk gives the
// device tree; df fills in used/free per mountpoint (robust across util-linux
// versions that lack lsblk's FSUSED columns).
app.get('/api/disks',auth,(req,res)=>{
  let disks=[];
  try{disks=JSON.parse(sync('lsblk -J -b -o NAME,TYPE,SIZE,FSTYPE,MOUNTPOINT,LABEL,MODEL,VENDOR,RM,RO 2>/dev/null',SPAWN_ENV)||'{}').blockdevices||[]}catch{}
  const usage={};
  try{
    for(const line of sync('df -P -B1 2>/dev/null',SPAWN_ENV).split('\n').slice(1)){
      const m=line.trim().match(/^(.+?)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)%\s+(\/.*)$/);
      if(m)usage[m[6]]={size:Number(m[2]),used:Number(m[3]),avail:Number(m[4]),usePct:Number(m[5])};
    }
  }catch{}
  const annotate=n=>{if(n.mountpoint&&usage[n.mountpoint])n.usage=usage[n.mountpoint];(n.children||[]).forEach(annotate)};
  disks.forEach(annotate);
  res.json({disks});
});

const projectRoots=()=>[PROJECTS_DEFAULT,path.join(HOME,'Projects'),path.join(HOME,'Developer'),path.join(HOME,'Code'),path.join(HOME,'src')].filter((x,i,a)=>a.indexOf(x)===i&&fs.existsSync(x));
function sync(cmd,env){try{return execSync(cmd,{encoding:'utf8',stdio:['ignore','pipe','ignore'],shell:'/bin/bash',env:env||process.env}).trim()}catch{return''}}
function detectProject(dir){let stack='Project',runCommand='',port=null,installCommand='';const pkgPath=path.join(dir,'package.json');if(fs.existsSync(pkgPath)){try{const p=JSON.parse(fs.readFileSync(pkgPath,'utf8'));const deps={...(p.dependencies||{}),...(p.devDependencies||{})};if(deps.vite){stack='Vite';port=5173}else if(deps.next){stack='Next.js';port=3000}else if(deps.react){stack='React';port=3000}else if(deps.vue){stack='Vue';port=5173}else if(deps['@angular/core']){stack='Angular';port=4200}else{stack='Node.js';port=3000}if(p.scripts?.dev)runCommand='npm run dev';else if(p.scripts?.start)runCommand='npm start';
  // --include=dev forces devDependencies to install even if NODE_ENV is set
  // to "production" somewhere in the environment (a user's shell profile,
  // inherited from another tool, etc). Without this, `npm install` silently
  // exits 0 while skipping every devDependency — which is exactly where
  // vite/next/etc. live — so the dev server binary never gets installed and
  // Run fails with "not found" despite the install step reporting success.
  installCommand=fs.existsSync(path.join(dir,'pnpm-lock.yaml'))?'pnpm install':fs.existsSync(path.join(dir,'yarn.lock'))?'yarn install':'npm install --include=dev'}catch{}}
else if(fs.existsSync(path.join(dir,'pyproject.toml'))||fs.existsSync(path.join(dir,'requirements.txt'))){stack='Python';runCommand='python3 -m http.server 8000';port=8000;installCommand=fs.existsSync(path.join(dir,'requirements.txt'))?'python3 -m pip install -r requirements.txt':''}
else if(fs.existsSync(path.join(dir,'Cargo.toml'))){stack='Rust';runCommand='cargo run';installCommand='cargo build'}
else if(fs.existsSync(path.join(dir,'go.mod'))){stack='Go';runCommand='go run .';port=8080}
const branch=sync(`git -C ${JSON.stringify(dir)} branch --show-current`);const changes=sync(`git -C ${JSON.stringify(dir)} status --porcelain`).split('\n').filter(Boolean).length;const running=[...runners.entries()].find(([,v])=>v.cwd===dir);
const remoteUrl=sync(`git -C ${JSON.stringify(dir)} remote get-url origin 2>/dev/null`);
const ghMatch=remoteUrl&&remoteUrl.match(/github\.com[:/]+([^/]+)\/([^/.]+?)(?:\.git)?\/?$/);
const nameWithOwner=ghMatch?`${ghMatch[1]}/${ghMatch[2]}`:null;
return{name:path.basename(dir),path:dir,stack,branch,changes,runCommand,installCommand,port:running?.[1]?.port||port,running:!!running,ready:!!running?.[1]?.ready,nameWithOwner}}
function scanProjects(){const out=[];for(const root of projectRoots()){for(const ent of fs.readdirSync(root,{withFileTypes:true}).filter(x=>x.isDirectory()&&!x.name.startsWith('.'))){const d=path.join(root,ent.name);if(fs.existsSync(path.join(d,'.git'))||fs.existsSync(path.join(d,'package.json'))||fs.existsSync(path.join(d,'pyproject.toml'))||fs.existsSync(path.join(d,'Cargo.toml'))||fs.existsSync(path.join(d,'go.mod')))out.push(detectProject(d));}}return out.sort((a,b)=>a.name.localeCompare(b.name))}
app.get('/api/projects',auth,(req,res)=>res.json({projects:scanProjects()}));
async function projectAction(req,res,kind){try{const dir=safeHome(req.body.path);if(kind==='install'){const p=detectProject(dir);if(!p.installCommand)throw new Error('No install command detected');const {stdout,stderr}=await sh(p.installCommand,{cwd:dir,timeout:10*60*1000,maxBuffer:10_000_000,shell:'/bin/bash',env:SPAWN_ENV});return res.json({message:(stdout+stderr).slice(-4000)})}if(kind==='run'){const p=detectProject(dir);if(!p.runCommand)throw new Error('No run command detected');
// Fresh clones have no node_modules — a dev server started without deps dies
// instantly and the preview shows a white screen. Auto-install first.
// Also catches the "node_modules exists but is broken" case: a partial or
// interrupted install (or one copied in from another machine/arch) leaves
// node_modules present but missing the actual package internals — e.g.
// vite/bin/vite.js exists but vite/dist/node/cli.js it imports does not.
// Checking only for node_modules' existence misses this entirely and the
// dev server crashes with ERR_MODULE_NOT_FOUND on every Run.
function installLooksBroken(dir){
  const nm=path.join(dir,'node_modules');
  if(!fs.existsSync(nm))return true;
  let pkg;try{pkg=JSON.parse(fs.readFileSync(path.join(dir,'package.json'),'utf8'))}catch{return false}
  const deps=Object.keys({...(pkg.dependencies||{}),...(pkg.devDependencies||{})});
  const critical=deps.filter(d=>['vite','next','vue','@angular/core','@angular/cli','react-scripts'].some(k=>d===k||d.startsWith(k)));
  for(const dep of critical){
    const depDir=path.join(nm,dep);
    if(!fs.existsSync(depDir))return true;
    let dpkg;
    try{
      const dpkgPath=path.join(depDir,'package.json');
      if(!fs.existsSync(dpkgPath))return true;
      dpkg=JSON.parse(fs.readFileSync(dpkgPath,'utf8'));
    }catch{return true}
    const bins=typeof dpkg.bin==='string'?{[dpkg.name]:dpkg.bin}:(dpkg.bin||{});
    for(const [binName,b] of Object.entries(bins)){
      const binPath=path.join(depDir,b);
      if(!fs.existsSync(binPath))return true;
      // npm run dev / bare `vite` resolves through node_modules/.bin/<name>,
      // a symlink npm creates as part of a real `npm install`. If the
      // package files were placed some other way (a raw copy/rsync/tarball
      // extraction, or an install that got interrupted after unpacking but
      // before linking), the package itself can be completely intact while
      // this symlink is simply never created — the shell then reports
      // "<name>: not found" even though nothing about the package is
      // actually broken. This was the real root cause here: vite/bin/vite.js
      // and vite/dist/node/cli.js were both fine; node_modules/.bin/vite
      // just didn't exist.
      const linkPath=path.join(nm,'.bin',binName);
      if(!fs.existsSync(linkPath))return true;
      // The bin wrapper existing on disk isn't enough — it's commonly a thin
      // file that imports/requires the tool's real entry point one level
      // deeper (e.g. vite/bin/vite.js containing `import '../dist/node/cli.js'`).
      // A truncated/interrupted install can leave the wrapper in place while
      // what it points to is missing, which crashes on Run with
      // ERR_MODULE_NOT_FOUND. We statically read the wrapper's own
      // import/require specifiers and confirm each resolved target exists —
      // this never executes the file (so it can't start a dev server or
      // have any other side effect), and it generalizes across frameworks
      // instead of hardcoding each one's internal layout.
      let src;try{src=fs.readFileSync(binPath,'utf8')}catch{return true}
      const specifiers=[...src.matchAll(/(?:from\s+|import\s+|import\s*\(|require\s*\(\s*)['"](\.[^'"]+)['"]/g)].map(m=>m[1]);
      for(const spec of specifiers){
        const base=path.join(path.dirname(binPath),spec);
        const candidates=[base,base+'.js',base+'.mjs',base+'.cjs',path.join(base,'index.js')];
        if(!candidates.some(c=>fs.existsSync(c)))return true;
      }
    }
  }
  return false;
}
const isNode=fs.existsSync(path.join(dir,'package.json'));
if(isNode&&installLooksBroken(dir)&&p.installCommand){
  try{await sh(`rm -rf node_modules package-lock.json && ${p.installCommand}`,{cwd:dir,timeout:10*60*1000,maxBuffer:20_000_000,shell:'/bin/bash',env:SPAWN_ENV})}
  catch(e){return res.status(400).json({error:'Dependency install failed:\n'+String(e.stderr||e.message).slice(-3000)})}
}
let port=p.port||5173;while([...runners.values()].some(x=>x.port===port))port++;let cmd=p.runCommand;if(p.stack==='Vite')cmd+=` -- --host 0.0.0.0 --port ${port}`;else if(p.stack==='Next.js')cmd+=` -- -H 0.0.0.0 -p ${port}`;else if(p.stack==='Vue')cmd+=` -- --host 0.0.0.0 --port ${port}`;else if(p.stack==='Angular')cmd+=` -- --host 0.0.0.0 --port ${port}`;const log=path.join(RUN_DIR,crypto.createHash('sha1').update(dir).digest('hex')+'.log');const fd=fs.openSync(log,'a');const child=spawn('/bin/bash',['-lc',cmd],{cwd:dir,detached:true,stdio:['ignore',fd,fd],env:{...SPAWN_ENV,HOST:'0.0.0.0',PORT:String(port)}});child.unref();const runnerEntry={pid:child.pid,cwd:dir,port,log,ready:false};runners.set(child.pid,runnerEntry);
// Wait up to ~20s for the port to actually accept connections, so we don't
// report success (and show a doomed preview) before the server is ready.
// A real TCP connect attempt (not a process/port-table check) is used
// because it doesn't depend on `ss`/`netstat` being installed, and it tests
// the exact thing the preview proxy will do a moment later.
async function portIsOpen(p){
  return new Promise((resolve)=>{
    const sock=net.createConnection({host:'127.0.0.1',port:p,timeout:900});
    sock.once('connect',()=>{sock.destroy();resolve(true)});
    sock.once('error',()=>{sock.destroy();resolve(false)});
    sock.once('timeout',()=>{sock.destroy();resolve(false)});
  });
}
let up=false;for(let i=0;i<40;i++){await new Promise(r=>setTimeout(r,500));if(await portIsOpen(port)){up=true;runnerEntry.ready=true;break}try{process.kill(child.pid,0)}catch{break}}
// Some dev servers (Next.js first compile, Angular) take longer than the
// 20s window above. Keep probing in the background so `ready` still flips
// true and the client's next poll of /api/projects picks it up, instead of
// requiring the user to hit Run again.
if(!up){(async()=>{for(let i=0;i<60;i++){await new Promise(r=>setTimeout(r,2000));if(!runners.has(child.pid))return;if(await portIsOpen(port)){runnerEntry.ready=true;return}}})();}
if(!up){const tail=(()=>{try{return fs.readFileSync(log,'utf8').slice(-2000)}catch{return''}})();return res.json({message:`Started on port ${port}, but it isn\u2019t responding yet. Still trying in the background \u2014 check back in a bit. Recent log:\n${tail}`,port,ready:false})}
return res.json({message:`Running on port ${port}`,port,ready:true})}if(kind==='stop'){for(const [pid,v]of runners){if(v.cwd===dir){try{process.kill(-pid,'SIGTERM')}catch{}runners.delete(pid)}}return res.json({message:'Stopped'})}if(kind==='pull'){const {stdout,stderr}=await sh('git pull',{cwd:dir});return res.json({message:stdout+stderr})}if(kind==='push'){const {stdout,stderr}=await sh('git push',{cwd:dir});return res.json({message:stdout+stderr})}if(kind==='commit'){const m=String(req.body.message||'').trim();if(!m)throw new Error('Commit message required');await sh('git add -A',{cwd:dir});const {stdout,stderr}=await sh(`git commit -m ${JSON.stringify(m)}`,{cwd:dir,shell:'/bin/bash'});return res.json({message:stdout+stderr})}}catch(e){res.status(400).json({error:e.stderr||e.message})}}
for(const k of ['install','run','stop','pull','push','commit'])app.post('/api/projects/'+k,auth,(req,res)=>projectAction(req,res,k));

app.post('/api/github/clone',auth,async(req,res)=>{try{const url=String(req.body.url||'').trim();if(!/^https?:\/\/github\.com\//.test(url)&&!/^git@github\.com:/.test(url))throw new Error('Enter a GitHub repository URL');const name=url.split('/').pop().replace(/\.git$/,'');const dest=path.join(PROJECTS_DEFAULT,name);await sh(`git clone ${JSON.stringify(url)} ${JSON.stringify(dest)}`,{timeout:10*60*1000,shell:'/bin/bash'});res.json({message:'Repository cloned',path:dest})}catch(e){res.status(400).json({error:e.stderr||e.message})}});
app.post('/api/github/login',auth,async(req,res)=>{const ok=sync('command -v gh');if(!ok)return res.json({message:'GitHub CLI is not installed. Install `gh` for your Linux distribution, then run `gh auth login` in Terminal.'});res.json({message:'Open Terminal and run: gh auth login. TouchWorkstation will use the credentials stored by GitHub CLI on this workstation.'})});
async function ghSafe(cmd){try{const {stdout}=await sh(cmd,{shell:'/bin/bash'});return stdout.trim()}catch{return''}}
app.get('/api/github/status',auth,async(req,res)=>{
  const connected=!!(await ghSafe('gh auth status 2>/dev/null && echo yes'));
  if(!connected)return res.json({connected:false,repos:[]});
  const [user,repoJson]=await Promise.all([
    ghSafe("gh api user --jq '.login' 2>/dev/null"),
    ghSafe("gh repo list --limit 8 --json nameWithOwner,description,stargazerCount,url,isPrivate,updatedAt 2>/dev/null"),
  ]);
  let repos=[];try{repos=JSON.parse(repoJson||'[]')}catch{}
  res.json({connected:true,user,repos});
});
app.get('/api/github/repos',auth,async(req,res)=>{
  const repoJson=await ghSafe("gh repo list --limit 50 --json nameWithOwner,description,stargazerCount,url,isPrivate,updatedAt 2>/dev/null");
  let repos=[];try{repos=JSON.parse(repoJson||'[]')}catch{}
  res.json({repos});
});

// Find a running Hermes web gateway and return a proxied URL for it. If none
// is running, report that so the client can offer to start it in a terminal.
app.get('/api/hermes/ui',auth,async(req,res)=>{
  for(const p of HERMES_PORTS){
    if(await probePort(p))return res.json({ready:true,url:`/preview/${p}/`,port:p});
  }
  res.json({ready:false});
});
// Start the Hermes gateway in a tracked background process, then report when
// its port is up so the client can open the UI.
app.post('/api/hermes/start',auth,async(req,res)=>{
  // Try the known gateway subcommands; whichever the installed hermes supports
  // will bind a port, the others fail harmlessly.
  const log=path.join(RUN_DIR,'hermes-gateway.log');
  const fd=fs.openSync(log,'a');
  const cmd='hermes serve 2>/dev/null || hermes gateway 2>/dev/null || hermes web 2>/dev/null || hermes daemon 2>/dev/null';
  const child=spawn('/bin/bash',['-lc',cmd],{cwd:HOME,detached:true,stdio:['ignore',fd,fd],env:SPAWN_ENV});
  child.unref();
  // Wait up to ~15s for any known gateway port to come up.
  for(let i=0;i<30;i++){
    await new Promise(r=>setTimeout(r,500));
    for(const p of HERMES_PORTS){if(await probePort(p))return res.json({ready:true,url:`/preview/${p}/`,port:p})}
    try{process.kill(child.pid,0)}catch{break}
  }
  const tail=(()=>{try{return fs.readFileSync(log,'utf8').slice(-1500)}catch{return''}})();
  res.json({ready:false,message:'Could not detect the Hermes web gateway automatically.',log:tail});
});
function loadConfig(){try{return JSON.parse(fs.readFileSync(CONFIG_FILE,'utf8'))}catch{return{projectFolders:projectRoots(),agentRuntime:null,onboarded:false}}}
function saveConfig(c){fs.mkdirSync(path.dirname(CONFIG_FILE),{recursive:true});fs.writeFileSync(CONFIG_FILE,JSON.stringify(c,null,2))}
app.post('/api/setup/complete',auth,(req,res)=>{const c=loadConfig();c.onboarded=true;saveConfig(c);res.json({ok:true})});
app.get('/api/settings',auth,(req,res)=>{const c=loadConfig();res.json({...c,github:!!sync('gh auth status 2>/dev/null && echo yes')})});
app.post('/api/settings',auth,(req,res)=>{
  const c=loadConfig();
  const body=req.body||{};
  if('theme' in body)c.theme=body.theme;
  if('uiVariant' in body&&(body.uiVariant==='omarchy'||body.uiVariant==='standard'))c.uiVariant=body.uiVariant;
  // Independent of uiVariant on purpose — same relationship as `theme` has
  // to everything else. uiVariant picks which build identity you're on;
  // this only ever matters once you're already on Omarchy, so it doesn't
  // belong folded into that same field.
  if('omarchyLayout' in body&&(body.omarchyLayout==='classic'||body.omarchyLayout==='tiled'))c.omarchyLayout=body.omarchyLayout;
  if('homeTiles' in body){
    const t=body.homeTiles;
    if(Array.isArray(t)&&t.every(x=>typeof x==='string'))c.homeTiles=t;
  }
  if('tiledPanes' in body){
    const t=body.tiledPanes;
    if(Array.isArray(t)&&t.every(x=>typeof x==='string'))c.tiledPanes=t;
  }
  if('tiledPalette' in body&&(body.tiledPalette==='mono'||body.tiledPalette==='color'))c.tiledPalette=body.tiledPalette;
  if('tiledGlass' in body)c.tiledGlass=!!body.tiledGlass;
  // Tiled appearance customization (Settings > Themes). Each is validated/clamped
  // so a bad value can never write junk that the client would then feed into CSS.
  if('tiledAccent' in body){const v=String(body.tiledAccent||'');if(/^#[0-9a-fA-F]{6}$/.test(v))c.tiledAccent=v;else if(v==='')delete c.tiledAccent}
  const clamp=(x,lo,hi)=>Math.min(hi,Math.max(lo,Number(x)));
  if('tiledGlassBlur' in body&&Number.isFinite(Number(body.tiledGlassBlur)))c.tiledGlassBlur=clamp(body.tiledGlassBlur,0,40);
  if('tiledGlassAlpha' in body&&Number.isFinite(Number(body.tiledGlassAlpha)))c.tiledGlassAlpha=clamp(body.tiledGlassAlpha,0,0.95);
  if('tiledWallDim' in body&&Number.isFinite(Number(body.tiledWallDim)))c.tiledWallDim=clamp(body.tiledWallDim,0,0.9);
  saveConfig(c);
  res.json({ok:true,theme:c.theme,homeTiles:c.homeTiles,uiVariant:c.uiVariant,omarchyLayout:c.omarchyLayout,tiledPanes:c.tiledPanes,tiledPalette:c.tiledPalette,tiledGlass:c.tiledGlass,tiledAccent:c.tiledAccent,tiledGlassBlur:c.tiledGlassBlur,tiledGlassAlpha:c.tiledGlassAlpha,tiledWallDim:c.tiledWallDim});
});

// ---- weather radar (CLI-style tile) --------------------------------------
// omastorm (the Omarchy weather plugin the user wanted) is a desktop-only
// Quickshell NEXRAD viewer — it can't render on the phone. This gives the
// tiled dashboard its own radar tile with the same pixelated look, rendered
// as block glyphs client-side. We build a REAL spatial precipitation grid by
// asking open-meteo for a grid of points around the location in ONE request
// (open-meteo returns an array for multiple lat/lon) — no image decoding, no
// new dependency, no API key. Cached briefly since radar only updates ~10min.
let weatherCache = { at: 0, data: null };
// Land/water mask is STATIC (terrain doesn't move), so cache it for the life
// of the process keyed by the grid — no need to re-fetch elevation every time.
const landCache = new Map();
async function landMask(lats, lons, COLS, ROWS, key) {
  if (landCache.has(key)) return landCache.get(key);
  // open-meteo's elevation API returns terrain elevation per point (0 over the
  // sea). elevation > 0 ⇒ land — a real coastline mask in one request, no
  // image decoding and no extra dependency. Coastal land at exactly 0m may read
  // as water; fine for an ASCII base map.
  let land = null;
  try {
    // The elevation API caps at 100 coordinates per request (the forecast API
    // allows more), so batch the grid into chunks of 100 and concatenate.
    const CHUNK = 100;
    const elev = [];
    for (let i = 0; i < lats.length; i += CHUNK) {
      const la = lats.slice(i, i + CHUNK), lo = lons.slice(i, i + CHUNK);
      const eu = `https://api.open-meteo.com/v1/elevation?latitude=${la.join(',')}&longitude=${lo.join(',')}`;
      const ej = await (await fetch(eu)).json();
      if (!Array.isArray(ej?.elevation)) throw new Error('bad elevation response');
      elev.push(...ej.elevation);
    }
    land = [];
    for (let r = 0; r < ROWS; r++) {
      const row = [];
      for (let c = 0; c < COLS; c++) { const e = elev[r * COLS + c]; row.push(typeof e === 'number' && e > 0); }
      land.push(row);
    }
  } catch { land = null; /* pane just skips the base map */ }
  landCache.set(key, land);
  return land;
}
app.get('/api/weather', auth, async (req, res) => {
  try {
    if (weatherCache.data && Date.now() - weatherCache.at < 5 * 60 * 1000) return res.json(weatherCache.data);
    // Location: public-IP geolocation (no key). Best-effort; degrades to an
    // error state the pane shows gracefully rather than faking a location.
    let lat, lon, place;
    try {
      const g = await (await fetch('https://ipapi.co/json/', { headers: { 'User-Agent': 'touchworkstation-weather' } })).json();
      lat = Number(g.latitude); lon = Number(g.longitude);
      place = [g.city, g.region_code || g.region].filter(Boolean).join(', ');
    } catch { /* fall through */ }
    if (!Number.isFinite(lat) || !Number.isFinite(lon)) return res.json({ ok: false, message: 'Could not determine your location for radar.' });
    // Grid of points spanning a regional radar-ish area around the center.
    const COLS = 22, ROWS = 13, spanLon = 2.4, spanLat = 1.5;
    const lats = [], lons = [];
    for (let r = 0; r < ROWS; r++) for (let c = 0; c < COLS; c++) {
      lats.push((lat + spanLat / 2 - (r / (ROWS - 1)) * spanLat).toFixed(3));
      lons.push((lon - spanLon / 2 + (c / (COLS - 1)) * spanLon).toFixed(3));
    }
    const url = `https://api.open-meteo.com/v1/forecast?latitude=${lats.join(',')}&longitude=${lons.join(',')}&current=precipitation,temperature_2m,weather_code`;
    const j = await (await fetch(url)).json();
    const arr = Array.isArray(j) ? j : [j];
    const grid = [];
    for (let r = 0; r < ROWS; r++) {
      const row = [];
      for (let c = 0; c < COLS; c++) row.push(Number(arr[r * COLS + c]?.current?.precipitation) || 0);
      grid.push(row);
    }
    const land = await landMask(lats, lons, COLS, ROWS, `${lat.toFixed(2)},${lon.toFixed(2)}:${COLS}x${ROWS}`);
    const center = arr[Math.floor(ROWS / 2) * COLS + Math.floor(COLS / 2)]?.current || arr[0]?.current || {};
    const data = {
      ok: true,
      place: place || `${lat.toFixed(2)}, ${lon.toFixed(2)}`,
      temp: center.temperature_2m ?? null,
      code: center.weather_code ?? null,
      cols: COLS, rows: ROWS, grid, land,
      at: new Date().toISOString(),
    };
    weatherCache = { at: Date.now(), data };
    res.json(data);
  } catch (e) {
    res.json({ ok: false, message: `Weather unavailable: ${e.message}` });
  }
});

// ---- wallpaper (Omarchy home-screen background) ----
// Stored in STATE_DIR, not ui/public — that directory is a build-time Vite
// asset folder that `emptyOutDir` wipes on every rebuild/update, which would
// silently delete a user's uploaded photo the next time the app updates.
// STATE_DIR survives rebuilds and is already writable by the app's own user
// with no special permissions (same place agents.json/config.json live).
const WALLPAPER_FILE=path.join(STATE_DIR,'wallpaper.jpg');
// Upload payload is a client-cropped JPEG data URL, not a raw multipart
// file — the crop happens in the browser (canvas), so the server only ever
// receives an already-sized, already-JPEG image. That sidesteps needing a
// multipart-parsing dependency (multer etc.) for what's fundamentally a
// small, fixed-format upload, keeping the dependency list unchanged.
app.post('/api/wallpaper',auth,(req,res)=>{
  const dataUrl=String(req.body?.image||'');
  const m=dataUrl.match(/^data:image\/(jpeg|jpg|png|webp);base64,(.+)$/);
  if(!m)return res.status(400).json({error:'Expected a base64 image data URL'});
  try{
    const buf=Buffer.from(m[2],'base64');
    if(buf.length>10*1024*1024)return res.status(400).json({error:'Image too large after decoding (max 10MB)'});
    fs.mkdirSync(STATE_DIR,{recursive:true});
    fs.writeFileSync(WALLPAPER_FILE,buf);
    res.json({ok:true});
  }catch(e){res.status(500).json({error:'Could not save wallpaper: '+e.message})}
});
app.delete('/api/wallpaper',auth,(req,res)=>{
  try{fs.unlinkSync(WALLPAPER_FILE)}catch{ /* already gone, or never set — either way the goal state is reached */ }
  res.json({ok:true});
});
// Served separately from the static dist/ bundle for the same reason it's
// stored outside ui/public — this file lives in STATE_DIR and can change at
// any time a user uploads a new one, independent of any build. `no-store`
// keeps the browser from caching a stale photo after a re-upload — unlike
// the content-hashed /assets/ files, this URL never changes even though its
// content does.
app.get('/wallpaper.jpg',auth,(req,res)=>{
  res.set('Cache-Control','no-store');
  if(!fs.existsSync(WALLPAPER_FILE))return res.status(404).end();
  // sendFile's `dotfiles` option defaults to 'ignore' — it treats ANY path
  // segment starting with "." as a hidden file and silently 404s rather
  // than serving it, which is exactly STATE_DIR (.local/share/...). Safe to
  // allow here specifically because WALLPAPER_FILE is a hardcoded constant,
  // never influenced by request input — there's no path-traversal surface
  // to protect against for this one fixed path.
  res.sendFile(WALLPAPER_FILE,{dotfiles:'allow'});
});
function classifyConnection(req){
  const host=(req.hostname||'').toLowerCase();
  if(host.endsWith('.ts.net'))return 'tailscale';
  const raw=(req.ip||req.socket?.remoteAddress||'').replace(/^::ffff:/,'');
  if(raw==='127.0.0.1'||raw==='::1')return 'local';
  const o=raw.split('.').map(Number);
  if(o.length===4){
    if(o[0]===100&&o[1]>=64&&o[1]<=127)return 'tailscale'; // Tailscale's CGNAT range
    if(o[0]===10||(o[0]===192&&o[1]===168)||(o[0]===172&&o[1]>=16&&o[1]<=31))return 'lan';
  }
  return 'other';
}
// How to reach this app from another device — shown as a banner when the
// terminal opens. The port is taken from the Host you connected on (through
// nginx that's 8088), falling back to TW_ACCESS_PORT or 8088. We list the
// current address first, then the mDNS name, the LAN IP, and Tailscale if up.
app.get('/api/access',auth,(req,res)=>{
  const host=String(req.headers.host||'');
  const port=(host.includes(':')?host.split(':').pop():'')||process.env.TW_ACCESS_PORT||'8088';
  const proto=req.secure?'https':'http';
  const hostname=os.hostname();
  const lanIp=Object.values(os.networkInterfaces()).flat().find(x=>x&&x.family==='IPv4'&&!x.internal)?.address||null;
  const urls=[];
  if(host)urls.push(`${proto}://${host}`);
  urls.push(`http://${hostname}.local:${port}`);
  if(lanIp)urls.push(`http://${lanIp}:${port}`);
  try{const ts=sync('tailscale ip -4 2>/dev/null',SPAWN_ENV);if(ts)urls.push(`http://${ts.trim()}:${port}`);}catch{}
  res.json({hostname,lanIp,port,urls:[...new Set(urls)]});
});

// ---- machines registry + discovery (the multi-machine switcher) -----------
// A saved list of the OTHER TouchWorkstation instances the user controls, kept
// on this (primary) instance. The stored password is used only to mint a
// session against the remote when proxying (Part 2) and is never returned to
// the client. Same JSON-on-disk pattern as loadConfig/saveConfig.
const MACHINES_FILE=path.join(STATE_DIR,'machines.json');
function loadMachines(){try{return JSON.parse(fs.readFileSync(MACHINES_FILE,'utf8'))}catch{return[]}}
// 0600: this file holds each remote machine's login password in plaintext
// (needed to relay/authenticate to them), so it must not be readable by other
// local users. chmod after write too, in case the file already existed 0644.
function saveMachines(list){fs.mkdirSync(path.dirname(MACHINES_FILE),{recursive:true});fs.writeFileSync(MACHINES_FILE,JSON.stringify(list,null,2),{mode:0o600});try{fs.chmodSync(MACHINES_FILE,0o600)}catch{}}
// Never leak the stored password to the client.
function publicMachine(m){return{id:m.id,name:m.name,baseUrl:m.baseUrl,hasCreds:!!m.password}}

app.get('/api/machines',auth,(req,res)=>{res.json({machines:loadMachines().map(publicMachine)})});
app.post('/api/machines',auth,(req,res)=>{
  const b=req.body||{};
  const name=String(b.name||'').trim();
  let baseUrl=String(b.baseUrl||'').trim().replace(/\/+$/,'');
  if(!baseUrl)return res.status(400).json({error:'A machine address (URL) is required.'});
  if(!/^https?:\/\//i.test(baseUrl))baseUrl='http://'+baseUrl;
  const list=loadMachines();
  const m={id:'m-'+Date.now().toString(36),name:name||baseUrl.replace(/^https?:\/\//,''),baseUrl,password:b.password?String(b.password):''};
  list.push(m);saveMachines(list);
  res.json({machine:publicMachine(m)});
});
app.put('/api/machines/:id',auth,(req,res)=>{
  const list=loadMachines();const i=list.findIndex(m=>m.id===req.params.id);
  if(i===-1)return res.status(404).json({error:'Machine not found'});
  const b=req.body||{};
  if('name'in b)list[i].name=String(b.name||'').trim()||list[i].name;
  if('baseUrl'in b&&b.baseUrl){let u=String(b.baseUrl).trim().replace(/\/+$/,'');if(!/^https?:\/\//i.test(u))u='http://'+u;list[i].baseUrl=u}
  if('password'in b&&b.password)list[i].password=String(b.password);
  saveMachines(list);res.json({machine:publicMachine(list[i])});
});
app.delete('/api/machines/:id',auth,(req,res)=>{
  const list=loadMachines();const next=list.filter(m=>m.id!==req.params.id);
  if(next.length===list.length)return res.status(404).json({error:'Machine not found'});
  saveMachines(next);res.json({ok:true});
});
// --- Cluster view: aggregate live hardware stats across the fleet ----------
// The primary logs into each registered machine once (with its stored password),
// caches the session cookie, then polls that machine's /api/status. This is a
// narrow read-only fetch, not the full reverse proxy — enough to render a
// side-by-side dashboard of every node's CPU / RAM / VRAM / disk / network.
const machineSessions=new Map(); // machine id -> tw_session cookie string
async function machineCookie(m,force){
  if(!force&&machineSessions.has(m.id))return machineSessions.get(m.id);
  if(!m.password)return null;
  const r=await fetch(m.baseUrl.replace(/\/+$/,'')+'/api/login',{
    method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({password:m.password}),signal:AbortSignal.timeout(5000),
  });
  const setc=r.headers.get('set-cookie');
  const cookie=setc?setc.split(';')[0]:null;
  if(cookie)machineSessions.set(m.id,cookie); else machineSessions.delete(m.id);
  return cookie;
}
async function fetchMachineStatus(m){
  const base=m.baseUrl.replace(/\/+$/,'');
  try{
    let cookie=await machineCookie(m);
    const get=()=>fetch(base+'/api/status',{headers:cookie?{cookie}:{},signal:AbortSignal.timeout(5000)});
    let r=await get();
    if(r.status===401&&m.password){cookie=await machineCookie(m,true);r=await get()} // stale cookie -> re-login once
    if(r.status===401)return {online:true,needsAuth:true};
    if(!r.ok)return {online:false,error:'HTTP '+r.status};
    return {online:true,status:await r.json()};
  }catch(e){return {online:false,error:e.name==='TimeoutError'?'timed out':(e.message||'unreachable')}}
}
app.get('/api/machines/stats',auth,async(req,res)=>{
  const list=loadMachines();
  const [self,others]=await Promise.all([
    computeStatus().then(status=>({id:'self',name:os.hostname(),self:true,online:true,status})).catch(()=>({id:'self',name:os.hostname(),self:true,online:false,error:'local error'})),
    Promise.all(list.map(async m=>({id:m.id,name:m.name,baseUrl:m.baseUrl,self:false,...(await fetchMachineStatus(m))}))),
  ]);
  res.json({machines:[self,...others]});
});
// Auto-detect other instances on the LAN via the mDNS service each install
// advertises (/etc/avahi/services/touchworkstation.service). Excludes self and
// anything already registered. Degrades to an empty list if avahi-browse isn't
// present (the wizard then shows manual-add only).
app.get('/api/machines/discover',auth,(req,res)=>{
  const self=os.hostname().toLowerCase();
  const known=new Set(loadMachines().map(m=>m.baseUrl));
  let found=[];
  try{
    // -r resolve, -p parseable, -t terminate after one pass. Parseable rows:
    // =;iface;proto;name;type;domain;host;address;port;txt
    const out=sync('avahi-browse -rptl _touchworkstation._tcp 2>/dev/null',SPAWN_ENV)||'';
    const seen=new Set();
    for(const line of out.split('\n')){
      if(!line.startsWith('='))continue;
      const f=line.split(';');
      const host=(f[6]||'').replace(/\.$/,'');const address=f[7]||'';const port=f[8]||'8088';
      if(!host)continue;
      const hn=host.replace(/\.local$/,'');
      if(hn.toLowerCase()===self)continue; // don't list ourselves
      const baseUrl=`http://${host}:${port}`;
      if(known.has(baseUrl))continue;
      const key=host+':'+port;if(seen.has(key))continue;seen.add(key);
      found.push({hostname:hn,host,address,port:Number(port)||8088,baseUrl});
    }
  }catch{ /* no avahi-browse -> empty */ }
  res.json({machines:found});
});
app.get('/api/vpn/status',auth,(req,res)=>{
  const connectionType=classifyConnection(req);
  const installed=!!sync('command -v tailscale',SPAWN_ENV);
  if(!installed)return res.json({installed:false,connected:false,ip:null,hostname:null,connectionType,viaTailscale:connectionType==='tailscale',secure:req.secure});
  const ip=sync('tailscale ip -4 2>/dev/null',SPAWN_ENV);
  let hostname=null,backendState=null;
  try{const j=JSON.parse(sync('tailscale status --json 2>/dev/null',SPAWN_ENV)||'{}');hostname=j.Self?.DNSName?.replace(/\\.$/,'')||null;backendState=j.BackendState||null}catch{}
  // Whether `tailscale serve` is already fronting the app on HTTPS (:443 → the
  // local app port), so the UI can skip the "turn on HTTPS" step.
  const serveStatus=sync('tailscale serve status 2>/dev/null',SPAWN_ENV);
  const httpsServed=/https:\/\//.test(serveStatus)&&serveStatus.includes(String(PORT));
  res.json({installed:true,connected:!!ip,ip:ip||null,hostname,backendState,connectionType,viaTailscale:connectionType==='tailscale',secure:req.secure,httpsUrl:hostname?`https://${hostname}`:null,httpsServed});
});
// Turn on HTTPS for the Tailscale hostname via `tailscale serve`, which
// auto-provisions a real cert (needs "HTTPS certificates" enabled in the tailnet
// admin console) and reverse-proxies :443 straight to the app — bypassing nginx,
// so the machine is reachable at https://<host>.ts.net instead of the nginx
// welcome page. Same sudo-or-fallback pattern as /api/vpn/up.
app.post('/api/vpn/serve',auth,async(req,res)=>{
  if(!sync('command -v tailscale',SPAWN_ENV))return res.status(400).json({error:'Tailscale is not installed yet.'});
  let hostname=null;try{hostname=JSON.parse(sync('tailscale status --json 2>/dev/null',SPAWN_ENV)||'{}').Self?.DNSName?.replace(/\\.$/,'')||null}catch{}
  const httpsUrl=hostname?`https://${hostname}`:null;
  const cmd=`tailscale serve --bg --https=443 http://127.0.0.1:${PORT}`;
  try{
    const {stdout,stderr}=await sh(`sudo -n ${cmd} 2>&1 || ${cmd} 2>&1`,{timeout:30000,env:SPAWN_ENV}).catch(e=>({stdout:e.stdout||'',stderr:e.stderr||e.message||''}));
    const out=((stdout||'')+(stderr||'')).trim();
    // Verify by asking serve status rather than trusting exit codes across
    // tailscale versions.
    const serveStatus=sync('tailscale serve status 2>/dev/null',SPAWN_ENV);
    if(/https:\/\//.test(serveStatus)&&serveStatus.includes(String(PORT)))return res.json({ok:true,httpsUrl,httpsServed:true});
    if(/https|cert|magicdns|admin|not enabled|enable/i.test(out))
      return res.json({needsAdmin:true,adminUrl:'https://login.tailscale.com/admin/dns',message:'Enable MagicDNS and HTTPS certificates for your tailnet in the Tailscale admin console, then try again.',detail:out.slice(-500)});
    return res.json({needsTerminal:true,command:`sudo ${cmd}`,message:'Run this once in Terminal to turn on HTTPS (it needs administrator access), then return here.',detail:out.slice(-500)});
  }catch(e){
    res.json({needsTerminal:true,command:`sudo ${cmd}`,message:'Run this once in Terminal to turn on HTTPS (it needs administrator access), then return here.'});
  }
});
// Attempt to install Tailscale. Distro-aware: on Arch, `tailscale` is a real
// package (and now a dependency), so use pacman; elsewhere use Tailscale's own
// installer. Returns installed:true if it worked, or the correct per-distro
// terminal command when we lack passwordless sudo.
app.post('/api/vpn/install',auth,async(req,res)=>{
  if(sync('command -v tailscale',SPAWN_ENV)){
    // Present but its daemon may be down (nothing enabled it) — try, best-effort.
    await sh('sudo -n systemctl enable --now tailscaled 2>/dev/null || true',{timeout:15000,env:SPAWN_ENV}).catch(()=>{});
    return res.json({installed:true,message:'Tailscale is already installed.'});
  }
  const pacman=!!sync('command -v pacman',SPAWN_ENV);
  const apt=!!sync('command -v apt-get',SPAWN_ENV);
  const dnf=!!sync('command -v dnf',SPAWN_ENV);
  const autoCmd=pacman?'pacman -Sy --noconfirm tailscale':'sh -c "curl -fsSL https://tailscale.com/install.sh | sh"';
  const termCmd=pacman?'sudo pacman -S tailscale && sudo systemctl enable --now tailscaled'
    :apt||dnf?'curl -fsSL https://tailscale.com/install.sh | sh'
    :'curl -fsSL https://tailscale.com/install.sh | sh';
  try{
    await sh(`sudo -n ${autoCmd}`,{timeout:10*60*1000,env:SPAWN_ENV});
    if(sync('command -v tailscale',SPAWN_ENV)){
      await sh('sudo -n systemctl enable --now tailscaled 2>/dev/null || true',{timeout:15000,env:SPAWN_ENV}).catch(()=>{});
      return res.json({installed:true,message:'Tailscale installed.'});
    }
    throw new Error('not installed after attempt');
  }catch{
    // No passwordless sudo — hand the user the right command for their distro.
    res.json({installed:false,needsTerminal:true,command:termCmd,message:'TouchWorkstation needs one command in Terminal to install Tailscale (it requires administrator access).'});
  }
});
// Bring Tailscale up and capture the sign-in URL so the user can authenticate
// by tapping a link instead of hunting through terminal output.
app.post('/api/vpn/up',auth,async(req,res)=>{
  if(!sync('command -v tailscale',SPAWN_ENV))return res.status(400).json({error:'Tailscale is not installed yet.'});
  if(sync('tailscale ip -4 2>/dev/null',SPAWN_ENV))return res.json({connected:true,message:'Remote access is already connected.'});
  // `tailscale up` fails if tailscaled isn't running ("failed to connect to
  // local tailscaled") — make sure the daemon is up first (best-effort).
  await sh('sudo -n systemctl enable --now tailscaled 2>/dev/null || true',{timeout:15000,env:SPAWN_ENV}).catch(()=>{});
  try{
    // tailscale up prints the auth URL to stderr; run non-interactively and capture it.
    const {stdout,stderr}=await sh('sudo -n tailscale up --timeout=5s 2>&1 || tailscale up --timeout=5s 2>&1',{timeout:20000,env:SPAWN_ENV}).catch(e=>({stdout:e.stdout||'',stderr:e.stderr||e.message||''}));
    const out=(stdout||'')+(stderr||'');
    const m=out.match(/https:\/\/login\.tailscale\.com\/[^\s]+/);
    if(m)return res.json({authUrl:m[0],message:'Open this link to sign in, then return here.'});
    if(sync('tailscale ip -4 2>/dev/null',SPAWN_ENV))return res.json({connected:true,message:'Connected.'});
    // Couldn't run tailscale up (needs sudo) — give the terminal fallback.
    res.json({needsTerminal:true,command:'sudo tailscale up',message:'Run this in Terminal to sign in, then return here.'});
  }catch(e){
    res.json({needsTerminal:true,command:'sudo tailscale up',message:'Run this in Terminal to sign in, then return here.'});
  }
});
// Arch-only auto-build support: no sudo, no sudoers file, nothing added to
// the packaging scripts. Detected by whether `makepkg` exists on PATH
// rather than an env var the installer would need to set — keeps this
// entirely self-contained in the app.
let hasMakepkg=null;
function makepkgAvailable(){
  if(hasMakepkg===null){
    try{execSync('command -v makepkg',{stdio:'ignore',env:{...process.env,PATH:twPath()},shell:'/bin/bash'});hasMakepkg=true}
    catch{hasMakepkg=false}
  }
  return hasMakepkg;
}
// Dedicated clone this feature owns end-to-end, independent of wherever the
// user may have manually cloned the repo for other purposes (e.g. ~/tws) —
// the server has no way to know that path, and re-guessing it is fragile.
const UPDATE_SRC_DIR=path.join(STATE_DIR,'update-src');
// idle | building | ready | error. `ready` carries the one command left to
// run by hand (a sudo pacman -U — deliberately NOT run by the app itself;
// see /api/update/apply's comment for why).
let updateBuild={status:'idle'};

// Check GitHub for a newer commit on master than what this server was
// built from, and tell the client whether this install can auto-build it
// (Arch, via makepkg) or only show the manual command. That manual
// command has to work identically on .deb/.rpm/Arch installs — it used to
// be a git-clone-and-makepkg command, which is Arch-only and does nothing
// useful on Ubuntu/Fedora (no PKGBUILD, no makepkg). Now that
// install.sh + the GitHub Actions release workflow exist, re-running the
// same one-line installer is the correct update command everywhere: it
// detects apt/dnf/pacman itself and installs whatever the latest release
// actually is, which naturally upgrades an already-installed package in
// place. Pulled straight from GitHub raw rather than the website's
// /api/public/install proxy, so this keeps working even if that proxy is
// ever misconfigured — this repo IS the source of truth for it either way.
app.get('/api/update/check',auth,async(req,res)=>{
  try{
    const r=await fetch('https://api.github.com/repos/TouchWorkStation/TouchWorkstation/commits/master',{headers:{'Accept':'application/vnd.github+json','User-Agent':'touchworkstation-update-check'}});
    if(!r.ok){res.json({status:'error',message:`GitHub said HTTP ${r.status} — try again later.`});return}
    const j=await r.json();
    const latest=String(j.sha||'').slice(0,12);
    const running=BUILD_SHA;
    const upToDate=latest&&running&&latest!=='unknown'&&latest===running;
    res.json({
      status:upToDate?'up-to-date':'update-available',
      running,
      latest:latest||'unknown',
      canAutoBuild:makepkgAvailable(),
      installCommand:'curl -fsSL https://raw.githubusercontent.com/TouchWorkStation/TouchWorkstation/master/install.sh | sh',
      message:upToDate
        ?`You're running the latest commit (${running}).`
        :`New commit available: ${latest} (running ${running}).`,
    });
  }catch(e){
    res.json({status:'error',message:`Could not reach GitHub: ${e.message}`});
  }
});

// Build the update — git pull/clone + `makepkg` (no -i). This needs no
// privilege at all: makepkg refuses to even run as root, and building
// without -i never touches pacman. The actual install (`sudo pacman -U`)
// stays a manual step the user runs themselves in their own terminal — the
// app never sees a sudo password and no sudoers rule is needed anywhere.
// Runs in the foreground (not detached): unlike a full -si install, this
// never restarts the service, so there's nothing that would kill this
// request handler mid-flight — it's just slow (npm install + vite build
// can take a couple of minutes), so the client polls
// /api/update/apply/status instead of waiting on this response.
app.post('/api/update/apply',auth,(req,res)=>{
  if(!makepkgAvailable()){
    return res.status(400).json({error:'Auto-build needs makepkg, which isn’t available on this install. Use the command from "Check for updates" in a terminal instead.'});
  }
  if(updateBuild.status==='building'){
    return res.status(409).json({error:'A build is already running.'});
  }
  updateBuild={status:'building',startedAt:new Date().toISOString()};
  res.json({status:'started'});
  const src=UPDATE_SRC_DIR;
  const archDir=path.join(src,'packaging','arch');
  // Reset --hard rather than a plain pull: this clone is dedicated to this
  // feature and nothing else touches it, but makepkg's own pkgver() step
  // writes a version bump into PKGBUILD in place on every build, which
  // would otherwise conflict with the next pull.
  const script=[
    `set -e`,
    `if [ -d ${JSON.stringify(src)}/.git ]; then cd ${JSON.stringify(src)} && git fetch origin master && git reset --hard origin/master; `+
    `else rm -rf ${JSON.stringify(src)} && git clone https://github.com/TouchWorkStation/TouchWorkstation.git ${JSON.stringify(src)}; fi`,
    `cd ${JSON.stringify(archDir)}`,
    `makepkg --noconfirm --needed`,
  ].join(' && ');
  const child=spawn('bash',['-lc',script],{cwd:HOME,env:SPAWN_ENV});
  let out='';
  child.stdout?.on('data',(d)=>{out+=d});
  child.stderr?.on('data',(d)=>{out+=d});
  child.on('error',(e)=>{updateBuild={status:'error',message:e.message}});
  child.on('close',(code)=>{
    if(code!==0){updateBuild={status:'error',message:'Build failed:\n'+out.slice(-2000)};return}
    try{
      const files=fs.readdirSync(archDir).filter((f)=>f.endsWith('.pkg.tar.zst')&&!f.includes('-debug-'));
      if(!files.length){updateBuild={status:'error',message:'Build finished but no package file was produced.'};return}
      const pkgFile=path.join(archDir,files[0]);
      updateBuild={status:'ready',command:`sudo pacman -U ${JSON.stringify(pkgFile)}`,readyAt:new Date().toISOString()};
    }catch(e){
      updateBuild={status:'error',message:e.message};
    }
  });
});
app.get('/api/update/apply/status',auth,(req,res)=>{res.json(updateBuild)});

// Preview reverse proxy: /preview/:port/* -> local dev server, served from
// the SAME origin as TouchWorkstation so it's reachable from any device
// (LAN or Tailscale) without exposing the raw dev port.
//
// Dev servers (Vite, webpack-dev-server, etc.) commonly emit ROOT-ABSOLUTE
// asset paths — Vite always injects `<script src="/@vite/client">`, and a
// typical index.html has `<script src="/src/main.jsx">`; the client script
// itself further imports things like `/node_modules/vite/dist/client/env.mjs`.
// Those resolve against the page's real origin per the URL spec — <base href>
// does NOT change resolution for root-absolute URLs, only relative ones — so
// they bypass the /preview/:port/ prefix entirely and hit TouchWorkstation's
// own root, which 404s or serves the wrong thing. That's what actually causes
// "the app loads but looks unstyled" — CSS/JS never really load.
// Rewriting every absolute reference in every HTML/JS/CSS response is
// fragile and incomplete (it's arbitrary JS). Instead: for HTML we rewrite
// the obvious src/href attributes AND set <base>, AND — the fix that
// actually closes the gap — a catch-all just before the SPA handler checks
// the Referer header; if a request arrived without the /preview/:port
// prefix but its Referer shows it came from a preview page, we know it's
// exactly this bypass case and proxy it to that same dev server.
async function proxyToDevServer(req,res,port){
  const target=`http://127.0.0.1:${port}${req.url}`;
  let lastErr=null;
  for(let attempt=0;attempt<4;attempt++){
    try{
      const r=await fetch(target,{headers:{...req.headers,host:`127.0.0.1:${port}`},redirect:'manual'});
      const ct=r.headers.get('content-type')||'';
      res.status(r.status);
      for(const [k,v]of r.headers){if(!['content-encoding','content-length','transfer-encoding','content-security-policy'].includes(k.toLowerCase()))res.setHeader(k,v)}
      if(ct.includes('text/html')){
        let html=await r.text();
        const base=`/preview/${port}`;
        html=html.replace(/((?:src|href)=)(["'])\/(?!\/)/gi,(m,attr,q)=>`${attr}${q}${base}/`);
        if(!/<base /i.test(html)) html=html.replace(/<head([^>]*)>/i,`<head$1><base href="${base}/">`);
        return res.send(html);
      }
      return res.send(Buffer.from(await r.arrayBuffer()));
    }catch(e){lastErr=e;await new Promise(r=>setTimeout(r,600))}
  }
  const refused=/ECONNREFUSED/.test(String(lastErr?.cause?.code||lastErr?.message||''));
  res.status(502).send(`<html><body style="font-family:system-ui;background:#0b090d;color:#e8e2ea;padding:24px;text-align:center"><h3 style="color:#ff7647">Dev server on port ${port} isn\u2019t reachable</h3><p style="color:#a99fae;font-size:14px">${refused?'Nothing is listening on that port yet. The dev server may still be starting, or it may have exited \u2014 check the Dev log on the project screen.':'The dev server returned an error. Check the Dev log on the project screen.'}</p></body></html>`);
}
app.use('/preview/:port',auth,async(req,res)=>{
  const port=Number(req.params.port);
  if(!Number.isInteger(port)||port<1024||port>65535)return res.status(400).send('Invalid port');
  await proxyToDevServer(req,res,port);
});
// Rescue root-absolute asset requests that escaped the /preview/:port
// prefix (see comment above) by checking whether the request's Referer
// shows it came from a preview page — this only fires for requests that
// didn't match the route above, so it never interferes with
// TouchWorkstation's own UI/API.
app.use((req,res,next)=>{
  const ref=req.headers.referer||'';
  const m=ref.match(/\/preview\/(\d+)\//);
  if(!m)return next();
  const port=Number(m[1]);
  if(!Number.isInteger(port)||port<1024||port>65535)return next();
  proxyToDevServer(req,res,port);
});

// API routes must be registered BEFORE the static handler and SPA catch-all,
// otherwise the catch-all returns index.html for /api/* requests.
mountAppRoutes(app,{auth,HOME});
// Foreground process of a given tw-<id> tmux session, or '' if there's no
// such session. Lets the agent routes tell "this CLI is already open, just
// reattach" apart from "this session is an idle shell, send the command".
async function paneCommand(sessionId){
  try{
    const {stdout}=await sh(`tmux list-panes -t ${JSON.stringify('tw-'+sessionId)} -F '#{pane_current_command}' 2>/dev/null || true`,{env:SPAWN_ENV});
    return stdout.trim().split('\n')[0]||'';
  }catch{return''}
}
mountAgentRoutes(app,{auth,HOME,stateDir:STATE_DIR,paneCommand});
mountBoardRoutes(app,{auth,stateDir:STATE_DIR});
mountDockerRoutes(app,{auth});
mountClipboardRoutes(app,{auth,stateDir:STATE_DIR});
mountNetworkRoutes(app,{auth,env:SPAWN_ENV,stateDir:STATE_DIR});
const dist=path.resolve(process.cwd(),'dist');
app.use(express.static(dist,{
  maxAge:'1y',
  immutable:true,
  setHeaders:(res,filePath)=>{
    // Only /assets/*.<hash>.js|css are safe to cache long — anything else
    // (index.html, sw.js, the manifest) must always be revalidated, or a
    // deploy can silently keep serving the previous build.
    if(!filePath.includes(`${path.sep}assets${path.sep}`)){
      res.setHeader('Cache-Control','no-store');
    }
  },
}));
app.use((req,res)=>res.set('Cache-Control','no-store').sendFile(path.join(dist,'index.html')));
const server=http.createServer(app);
attachPty(server,{jwtSecret:JWT_SECRET,home:HOME});
server.listen(PORT,'0.0.0.0',()=>console.log(`TouchWorkstation listening on :${PORT}`));

// Optional HTTPS listener. This is what actually flips isSecureContext to
// true in the browser, which is required for the Clipboard API (native
// copy/paste) to work at all — Tailscale alone (a private network path)
// does not do this on its own.
//
// Deliberately non-privileged (8443, not 443): binding 443 needs either
// root or a capability grant on the systemd unit, which isn't something
// this app can set up for itself. 8443 needs nothing extra and works
// immediately with the existing service as-is.
//
// Fully optional and backwards-compatible: if no cert is present yet, this
// block does nothing at all and the existing HTTP server on PORT keeps
// working exactly as it does today. See TLS-SETUP.md for how to generate
// the cert with `tailscale cert`.
const HTTPS_PORT=Number(process.env.HTTPS_PORT||8443);
const TLS_DIR=process.env.TW_TLS_DIR||path.join(HOME,'.touchworkstation','tls');
const tlsCertPath=path.join(TLS_DIR,'cert.pem'),tlsKeyPath=path.join(TLS_DIR,'key.pem');
if(fs.existsSync(tlsCertPath)&&fs.existsSync(tlsKeyPath)){
  try{
    const httpsServer=https.createServer({cert:fs.readFileSync(tlsCertPath),key:fs.readFileSync(tlsKeyPath)},app);
    attachPty(httpsServer,{jwtSecret:JWT_SECRET,home:HOME});
    httpsServer.listen(HTTPS_PORT,'0.0.0.0',()=>console.log(`TouchWorkstation HTTPS listening on :${HTTPS_PORT}`));
  }catch(e){
    console.error(`Found a TLS cert at ${TLS_DIR} but couldn't start HTTPS: ${e.message}`);
  }
}else{
  console.log(`No TLS cert at ${TLS_DIR} — HTTPS not started. See TLS-SETUP.md.`);
}
